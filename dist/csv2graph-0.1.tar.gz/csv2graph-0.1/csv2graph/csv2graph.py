# -*- coding: utf-8 -*-
#
# Nom du fichier:       csv2graph.py
# Date de création:     08/04/2023
# Version:              0.0.1
# Auteur:               Simon STEPHAN <simon.stephan@u-bourgogne.fr>
#
# Copyright (c) 2023,
# Tous droits réservés. 
#

class Csv2LinkedObjects:
    """ Description Csv2LinkedObjects : 
    """

    def __init__(self):
        pass
